require("chai").should()

describe("** App **", () => {
  it("should pass", () => {
    const value = 1

    value.should.equal(1)
  })
})
