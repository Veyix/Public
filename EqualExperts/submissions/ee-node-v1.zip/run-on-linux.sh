#!/bin/bash

echo Restoring packages...
npm install

echo Running tests...
npm test

echo Running the program...
npm start

echo Done!
