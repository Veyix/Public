namespace FizzBuzz
{
    public interface IOutputter
    {
        void Output(string value);
    }
}